# Dex++ PRIME: Luau otimizado + Core Rust

Este pacote parte do arquivo `newrepository.lua` do ZIP fornecido pelo usuário.

## O que realmente está incluído

- `newrepository_prime.lua`: **Dex++ original inteiro com otimizações conservadoras** no subsistema Explorer. Mantém as chamadas e as dependências Luau/Roblox do projeto original. Não há garantia de funcionamento ou compatibilidade com executores, nem de aceleração específica.
- `newrepository_original.lua`: cópia intacta para comparar/reverter.
- `dexprime_core/`: CLI **Rust** independente, somente leitura, que explora snapshots `TSV` da árvore Roblox, com cache de nomes normalizados e índice de IDs. Não injeta código, não faz Attach e **não substitui** o script Luau.
- `roblox_studio/export_snapshot_studio.luau`: exportador opcional de hierarquia para uso na Barra de Comandos do Roblox Studio em experiências que você pode editar. Não use em jogos de terceiros.
- `samples/demo.tsv`: exemplo para testar os comandos.
- `roblox_studio/benchmark_search_studio.luau`: microbenchmark opcional da busca de nomes, rodado no Studio (sem Attach).

## Otimizações aplicadas no Luau

1. **Cache de nomes case-insensitive** por nó. Só converte novamente para minúsculas quando o nome realmente muda.
2. **Busca simples direta**: termos sem operadores avançados usam a busca integrada, evitando construir/compilar uma função via `loadstring` a cada pesquisa.
3. **Busca avançada preservada**: `/filtros`, aspas, `&&`, `||`, `!`, parênteses continuam usando o parser original.

**Limitações:** a versão `PRIME` não reescreve os 21 mil trechos do Dex++ nem altera o acesso a `CoreGui`, `getgenv`, `getreg` e outras APIs específicas do ambiente. O arquivo `adoptme_stable.lua` incluído no ZIP original está ofuscado e não foi executado, nem portado.

## Rust: como compilar (Windows/macOS/Linux)

Instale Rust pela fonte oficial: https://rustup.rs

```bash
cd dexprime_core
cargo test
cargo build --release
```

O executável estará em `target/release/dexprime-core` (ou `dexprime-core.exe` no Windows).

Exemplos a partir de `dexprime_core/`:

```bash
cargo run --release -- stats ../samples/demo.tsv
cargo run --release -- search ../samples/demo.tsv dracula
cargo run --release -- search ../samples/demo.tsv part --class Part
cargo run --release -- tree ../samples/demo.tsv --depth 4
cargo run --release -- inspect ../samples/demo.tsv 4
cargo run --release -- bench 100000 30
```

O formato TSV usa quatro colunas: `id`, `parent_id` (0 para raiz), `class`, `name`. Caracteres `\t`, `\n`, `\r` e `\\` nos nomes são escapados. Não inclui propriedades arbitrárias, nem permite editar o jogo.

## Exportar seu próprio snapshot

No **Roblox Studio**, com permissão para editar a experiência:

1. Abra **View > Command Bar** (Exibir > Barra de Comandos).
2. Cole o conteúdo de `roblox_studio/export_snapshot_studio.luau` na Barra de Comandos e execute.
3. Será criado `ServerStorage/DexPrime_Snapshot_TSV` **desativado**, contendo o texto TSV na propriedade Source.
4. Abra esse script no editor, copie todo o texto e salve em `snapshot.tsv` com codificação UTF-8 no computador.
5. Execute `cargo run --release -- search ../snapshot.tsv dracula` (ajuste o caminho conforme o local do arquivo).

Não é necessário usar Potassium nem Attach para rodar o programa Rust.

## Desempenho honesto

O Core Rust implementa pesquisa linear O(N) com nome já normalizado, índice O(1) médio por ID e travessia iterativa. Isso não comprova 1000x de ganho. Para comparar versões, cronometre *o mesmo conjunto de objetos e a mesma consulta* nos dois ambientes e use a mediana de várias repetições. O comando `bench` mede **apenas** o Rust com dados sintéticos; não é comparação direta com Luau. No Studio, `benchmark_search_studio.luau` permite comparar apenas o custo de busca/conversão de nomes com a mesma lista de objetos.

**Validação:** a estrutura do pacote e as alterações de texto foram conferidas. Este ambiente não dispõe do compilador Rust nem do Roblox Studio, portanto a compilação e os testes de execução devem ser realizados na máquina do usuário; não afirmamos que já passaram.

## Avisos

- Compilar Rust não produz um `loadstring` utilizável no Roblox.
- Código externo e scripts de executor podem trazer riscos de segurança e violar regras da plataforma. Inspecione antes de executar; não desative proteção do Windows para isso.
- O código original foi preservado sem análise completa de segurança. Nenhum dos arquivos foi executado dentro de Roblox.
