//! Dex++ PRIME Core
//! CLI local de leitura e busca de snapshots TSV. Nao interage com processo Roblox.
//! Sem dependencias externas; as buscas reutilizam nomes normalizados.

use std::collections::{BTreeMap, HashMap};
use std::env;
use std::fs;
use std::process;
use std::time::Instant;

#[derive(Debug)]
struct Node {
    id: u64,
    parent: Option<usize>,
    children: Vec<usize>,
    class_name: String,
    name: String,
    class_lower: String,
    name_lower: String,
}

struct Explorer {
    nodes: Vec<Node>,
    index_by_id: HashMap<u64, usize>,
    roots: Vec<usize>,
}

fn decode_field(value: &str) -> Result<String, String> {
    let mut chars = value.chars();
    let mut output = String::with_capacity(value.len());
    while let Some(c) = chars.next() {
        if c != '\\' {
            output.push(c);
            continue;
        }
        let escaped = chars.next().ok_or("escape final incompleto")?;
        match escaped {
            't' => output.push('\t'),
            'n' => output.push('\n'),
            'r' => output.push('\r'),
            '\\' => output.push('\\'),
            other => return Err(format!("escape nao reconhecido: \\{other}")),
        }
    }
    Ok(output)
}

impl Explorer {
    fn from_tsv(text: &str) -> Result<Self, String> {
        let mut nodes = Vec::<Node>::new();
        let mut by_id = HashMap::<u64, usize>::new();
        let mut pending_parents = Vec::<Option<u64>>::new();

        for (line_no, raw) in text.lines().enumerate() {
            let line = raw.trim_end_matches('\r');
            if line.is_empty() || line == "id\tparent_id\tclass\tname" { continue; }
            let cols: Vec<&str> = line.splitn(4, '\t').collect();
            if cols.len() != 4 {
                return Err(format!("linha {}: 4 colunas TSV esperadas", line_no + 1));
            }
            let id: u64 = cols[0].parse().map_err(|_| format!("linha {}: id invalido", line_no + 1))?;
            if id == 0 || by_id.contains_key(&id) {
                return Err(format!("linha {}: id zero ou duplicado: {id}", line_no + 1));
            }
            let parent_id: u64 = cols[1].parse().map_err(|_| format!("linha {}: parent_id invalido", line_no + 1))?;
            if parent_id == id { return Err(format!("linha {}: pai igual ao proprio no", line_no + 1)); }
            let class_name = decode_field(cols[2])?;
            let name = decode_field(cols[3])?;
            let index = nodes.len();
            by_id.insert(id, index);
            pending_parents.push(if parent_id == 0 { None } else { Some(parent_id) });
            nodes.push(Node {
                id,
                parent: None,
                children: Vec::new(),
                class_lower: class_name.to_lowercase(),
                name_lower: name.to_lowercase(),
                class_name,
                name,
            });
        }

        let mut roots = Vec::new();
        for (i, parent_id) in pending_parents.iter().copied().enumerate() {
            if let Some(pid) = parent_id {
                let parent_idx = by_id.get(&pid).copied()
                    .ok_or_else(|| format!("id {}: pai {pid} nao encontrado", nodes[i].id))?;
                nodes[i].parent = Some(parent_idx);
                nodes[parent_idx].children.push(i);
            } else {
                roots.push(i);
            }
        }
        // Uma hierarquia com ciclos ou raizes ausentes e rejeitada.
        let mut visited = vec![false; nodes.len()];
        let mut stack = roots.clone();
        let mut seen = 0usize;
        while let Some(i) = stack.pop() {
            if visited[i] { return Err(format!("ciclo detectado no id {}", nodes[i].id)); }
            visited[i] = true;
            seen += 1;
            stack.extend(nodes[i].children.iter().copied());
        }
        if seen != nodes.len() { return Err("hierarquia invalida: ha um ciclo ou no sem raiz".into()); }

        Ok(Self { nodes, index_by_id: by_id, roots })
    }

    fn open(path: &str) -> Result<Self, String> {
        let input = fs::read_to_string(path).map_err(|e| format!("nao foi possivel ler {path}: {e}"))?;
        Self::from_tsv(&input)
    }

    fn path_of(&self, mut index: usize) -> String {
        let mut parts = Vec::<&str>::new();
        loop {
            let node = &self.nodes[index];
            parts.push(&node.name);
            match node.parent { Some(parent) => index = parent, None => break }
        }
        parts.reverse();
        parts.join("/")
    }

    fn search<'a>(&'a self, term: &str, class: Option<&str>, case_sensitive: bool, limit: usize) -> Vec<&'a Node> {
        let q = if case_sensitive { term.to_owned() } else { term.to_lowercase() };
        let class_lower = class.map(str::to_lowercase);
        self.nodes.iter()
            .filter(|n| {
                let name_match = if case_sensitive { n.name.contains(&q) } else { n.name_lower.contains(&q) };
                let class_match = match class_lower.as_deref() {
                    Some(wanted) => n.class_lower == wanted,
                    None => true,
                };
                name_match && class_match
            })
            .take(limit)
            .collect()
    }

    fn stats(&self) {
        println!("Objetos: {}", self.nodes.len());
        println!("Raizes: {}", self.roots.len());
        let mut by_class = BTreeMap::<&str, usize>::new();
        let mut max_depth = 0usize;
        let mut stack: Vec<(usize, usize)> = self.roots.iter().map(|&i| (i, 0)).collect();
        while let Some((index, depth)) = stack.pop() {
            max_depth = max_depth.max(depth);
            *by_class.entry(&self.nodes[index].class_name).or_insert(0) += 1;
            for &child in &self.nodes[index].children { stack.push((child, depth + 1)); }
        }
        println!("Profundidade maxima: {max_depth}");
        let mut classes: Vec<(&str, usize)> = by_class.into_iter().collect();
        classes.sort_unstable_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(b.0)));
        println!("Top 15 classes:");
        for (name, count) in classes.into_iter().take(15) { println!("  {:>8} {}", count, name); }
    }

    fn print_tree(&self, root_id: Option<u64>, depth_limit: usize, print_limit: usize) -> Result<(), String> {
        let starts = match root_id {
            Some(id) => vec![*self.index_by_id.get(&id).ok_or(format!("id {id} nao encontrado"))?],
            None => self.roots.clone(),
        };
        let mut stack: Vec<(usize, usize)> = starts.into_iter().rev().map(|i| (i, 0)).collect();
        let mut shown = 0usize;
        while let Some((index, depth)) = stack.pop() {
            let node = &self.nodes[index];
            println!("{}{} [{}] (id={})", "  ".repeat(depth), node.name, node.class_name, node.id);
            shown += 1;
            if shown >= print_limit {
                println!("... limite de {print_limit} objetos atingido");
                break;
            }
            if depth < depth_limit {
                for &child in node.children.iter().rev() { stack.push((child, depth + 1)); }
            }
        }
        Ok(())
    }

    fn inspect(&self, id: u64) -> Result<(), String> {
        let index = *self.index_by_id.get(&id).ok_or(format!("id {id} nao encontrado"))?;
        let node = &self.nodes[index];
        let mut descendants = 0usize;
        let mut stack = node.children.clone();
        while let Some(i) = stack.pop() {
            descendants += 1;
            stack.extend(self.nodes[i].children.iter().copied());
        }
        println!("Id: {}\nNome: {}\nClasse: {}\nCaminho: {}\nFilhos imediatos: {}\nDescendentes: {}",
            node.id, node.name, node.class_name, self.path_of(index), node.children.len(), descendants);
        Ok(())
    }
}

fn sample_benchmark(count: usize, loops: usize) {
    let started = Instant::now();
    let mut data = String::from("id\tparent_id\tclass\tname\n");
    for i in 1..=count {
        let parent = if i == 1 { 0 } else { (i - 2) / 5 + 1 };
        let class = if i % 5 == 0 { "Part" } else { "Model" };
        data.push_str(&format!("{i}\t{parent}\t{class}\tObjeto_{i}\n"));
    }
    let tree = Explorer::from_tsv(&data).expect("benchmark gerou dados invalidos");
    let build_time = started.elapsed();
    let test_start = Instant::now();
    let mut hits = 0usize;
    for _ in 0..loops {
        hits += tree.search("objeto_999", None, false, usize::MAX).len();
    }
    let took = test_start.elapsed();
    println!("Objetos: {count} | loops: {loops} | matches totais: {hits}");
    println!("Criacao + indexacao: {:.3}s", build_time.as_secs_f64());
    println!("Busca: {:.3}s total | {:.3}ms/busca", took.as_secs_f64(), took.as_secs_f64() * 1000.0 / loops as f64);
    println!("Nota: benchmark sintetico; nao e comparacao contra Dex++ Luau.");
}

fn parse_usize(value: Option<&String>, default: usize, name: &str) -> Result<usize, String> {
    match value {
        Some(s) => s.parse().map_err(|_| format!("{name} deve ser inteiro positivo")),
        None => Ok(default),
    }
}

fn usage() {
    println!("Dex++ PRIME Core (Rust) - leitura local, sem injecao no Roblox");
    println!("\nUso:");
    println!("  dexprime-core stats <snapshot.tsv>");
    println!("  dexprime-core search <snapshot.tsv> <termo> [--class Classe] [--limit N] [--case-sensitive]");
    println!("  dexprime-core tree <snapshot.tsv> [id_raiz] [--depth N] [--limit N]");
    println!("  dexprime-core inspect <snapshot.tsv> <id>");
    println!("  dexprime-core bench [numero_objetos] [repeticoes]");
}

fn run() -> Result<(), String> {
    let args: Vec<String> = env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("stats") => {
            let file = args.get(2).ok_or("informe o arquivo TSV")?;
            Explorer::open(file)?.stats();
        }
        Some("search") => {
            let file = args.get(2).ok_or("informe o arquivo TSV")?;
            let term = args.get(3).ok_or("informe o termo")?;
            let mut class = None;
            let mut limit = 50usize;
            let mut case_sensitive = false;
            let mut i = 4;
            while i < args.len() {
                match args[i].as_str() {
                    "--class" => {
                        i += 1;
                        class = Some(args.get(i).ok_or("classe ausente")?.as_str());
                    }
                    "--limit" => {
                        i += 1;
                        limit = parse_usize(args.get(i), 50, "limit")?;
                    }
                    "--case-sensitive" => case_sensitive = true,
                    other => return Err(format!("opcao desconhecida: {other}")),
                }
                i += 1;
            }
            let tree = Explorer::open(file)?;
            let started = Instant::now();
            let matches = tree.search(term, class, case_sensitive, limit);
            let duration = started.elapsed();
            for node in &matches {
                let index = tree.index_by_id[&node.id];
                println!("{:>7} {:<16} {}", node.id, node.class_name, tree.path_of(index));
            }
            println!("{} resultados exibidos em {:.3}ms (limite {})", matches.len(), duration.as_secs_f64() * 1000.0, limit);
        }
        Some("tree") => {
            let file = args.get(2).ok_or("informe o arquivo TSV")?;
            let mut root_id = None;
            let mut depth = 5usize;
            let mut limit = 250usize;
            let mut i = 3;
            while i < args.len() {
                match args[i].as_str() {
                    "--depth" => { i += 1; depth = parse_usize(args.get(i), 5, "depth")?; }
                    "--limit" => { i += 1; limit = parse_usize(args.get(i), 250, "limit")?; }
                    value if !value.starts_with('-') && root_id.is_none() => {
                        root_id = Some(value.parse::<u64>().map_err(|_| "id_raiz invalido")?);
                    }
                    other => return Err(format!("opcao desconhecida: {other}")),
                }
                i += 1;
            }
            Explorer::open(file)?.print_tree(root_id, depth, limit)?;
        }
        Some("inspect") => {
            let file = args.get(2).ok_or("informe o arquivo TSV")?;
            let id: u64 = args.get(3).ok_or("informe o id")?
                .parse().map_err(|_| "id invalido")?;
            Explorer::open(file)?.inspect(id)?;
        }
        Some("bench") => {
            let count = parse_usize(args.get(2), 100_000, "numero_objetos")?;
            let loops = parse_usize(args.get(3), 30, "repeticoes")?;
            if count == 0 || loops == 0 { return Err("use contagens maiores que zero".into()); }
            sample_benchmark(count, loops);
        }
        _ => usage(),
    }
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("Erro: {error}");
        usage();
        process::exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn demo() -> Explorer {
        Explorer::from_tsv("id\tparent_id\tclass\tname\n1\t0\tDataModel\tgame\n2\t1\tWorkspace\tWorkspace\n3\t2\tPart\tPeca Azul\n4\t2\tPart\tPeça Vermelha\n").unwrap()
    }

    #[test]
    fn names_and_paths() {
        let x = demo();
        assert_eq!(x.search("peça", None, false, 50).len(), 1);
        assert_eq!(x.search("PECA", Some("Part"), false, 50).len(), 1);
        assert_eq!(x.path_of(x.index_by_id[&3]), "game/Workspace/Peca Azul");
    }

    #[test]
    fn escapings() {
        assert_eq!(decode_field("um\\tdois\\ntrês\\\\x").unwrap(), "um\tdois\ntrês\\x");
        assert!(decode_field("xx\\Q").is_err());
    }

    #[test]
    fn invalid_parent_and_cycles() {
        assert!(Explorer::from_tsv("1\t2\tPart\ta\n2\t1\tPart\tb\n").is_err());
        assert!(Explorer::from_tsv("1\t0\tPart\ta\n2\t42\tPart\tb\n").is_err());
    }

    #[test]
    fn bad_duplicate_ids() {
        assert!(Explorer::from_tsv("1\t0\tPart\ta\n1\t0\tPart\tb\n").is_err());
    }
}
